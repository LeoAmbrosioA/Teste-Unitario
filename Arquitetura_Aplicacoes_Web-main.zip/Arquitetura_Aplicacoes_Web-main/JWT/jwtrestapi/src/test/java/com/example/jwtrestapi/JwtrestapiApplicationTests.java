package com.example.jwtrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
